import React from "react";
import "./App.css";
import DatasetTableWithAgGrid from "./DatasetTableWithAgGrid";

function App() {
  return (
    <div className="App">
      <DatasetTableWithAgGrid />
    </div>
  );
}

export default App;
