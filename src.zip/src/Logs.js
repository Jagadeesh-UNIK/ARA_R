import React from "react";

function Logs() {
  return <div>Welcome to Logs</div>;
}

export default Logs;
