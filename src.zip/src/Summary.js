import React from "react";

function Summary() {
  return <div>Welcome to Summary</div>;
}

export default Summary;
